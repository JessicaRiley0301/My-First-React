import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
    <h1>Hello Dojo ⚔️</h1>
    <p>Things I need to do</p>
    <ul>
      <li>Learn React</li>
      <li>Climb Mt. Everest</li>
      <li>Run a mountain</li>
      <li>Feed the Dogs</li>
    </ul>
    </div>
  );
}

export default App;
